export default function VolleyballTracker() {
  return (
    <div style={{ padding: 20 }}>
      <h1>🏐 Volleyball Match Tracker</h1>
      <p>Project scaffold – klaar voor uitbreiding.</p>
    </div>
  );
}
